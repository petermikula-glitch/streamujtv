# -*- coding: utf-8 -*-
"""Router a obrazovky doplňku."""
import json
from datetime import date
from itertools import islice
import sqlite3
import sys
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import catalog
import csfd
import exporter
from nameparser import normalize, parse
import provider
from db import Library
from kodiutils import (_, ADDON, ADDON_ID, FANART, ICON, KODI_MAJOR, Progress, keyboard, log,
                       log_error, log_info, notify, number, ok, profile_path, select, set_setting,
                       setting, setting_bool, setting_int, text_viewer, yesno)
from tmdb import IMG, Tmdb, TmdbError

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else "plugin://%s/" % ADDON_ID
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1

LANG_OPTIONS = ["CZ", "SK", "EN", ""]
QUALITY_OPTIONS = ["", "UHD", "FHD", "HD", "SD"]


def url_for(action, **params):
    params["action"] = action
    return BASE_URL + "?" + urllib.parse.urlencode(
        dict((k, v) for k, v in params.items() if v is not None and v != ""))


PLAYING_PROPERTY = ADDON_ID + ".playing"


def open_library():
    return Library(profile_path("catalog.db"), video_key=provider.video_key, prefer_ref=provider.prefer_ref)


_PLAYBACK = {}


def _playback_state():
    """{"resume": {vid: (pozice, délka)}, "watched": set()} – načte se jednou za běh."""
    if not _PLAYBACK:
        with open_library() as lib:
            _PLAYBACK["resume"] = lib.resume_points()
            _PLAYBACK["watched"] = lib.watched()
    return _PLAYBACK


def _apply_playback(li, vid):
    state = _playback_state()
    point = state["resume"].get(vid)
    if KODI_MAJOR >= 20:
        tag = li.getVideoInfoTag()
        if point:
            tag.setResumePoint(float(point[0]), float(point[1]))
        if vid in state["watched"]:
            tag.setPlaycount(1)
    else:
        if point:
            li.setProperty("ResumeTime", str(int(point[0])))
            li.setProperty("TotalTime", str(int(point[1])))
        if vid in state["watched"]:
            li.setInfo("video", {"playcount": 1})


def make_client():
    return provider.make_client(setting("username"), setting("password"),
                                location=setting("location") or "1",
                                cookie_file=profile_path("cookies.lwp"), log=log)


def make_tmdb():
    return Tmdb(setting("tmdb_key"), log=log)


# ---------------------------------------------------------------------------
# Tvorba položek
# ---------------------------------------------------------------------------

def _display_title(meta):
    return meta.get("title") or meta.get("search_title") or ""


def _display_year(meta):
    return meta.get("year") or meta.get("search_year") or 0


def _plot(meta, extra_lines=None):
    lines = []
    if meta.get("rating") and setting_bool("show_rating"):
        src = {"csfd": "ČSFD", "tmdb": "TMDB", "manual": _(30329)}.get(meta.get("rating_source"), "")
        votes = (" (%s)" % meta["votes"]) if meta.get("votes") else ""
        lines.append("[B]%s %s: %d %%[/B]%s" % (_(30329), src, meta["rating"], votes))
    if extra_lines:
        lines.extend(x for x in extra_lines if x)
    if meta.get("plot"):
        lines.append(meta["plot"])
    return "\n".join(lines)


def _set_info(li, info, cast=None):
    """Kodi 20+ používá InfoTagVideo, Kodi 19 setInfo."""
    if KODI_MAJOR >= 20:
        tag = li.getVideoInfoTag()
        setters = {
            "title": tag.setTitle, "originaltitle": tag.setOriginalTitle, "plot": tag.setPlot,
            "mediatype": tag.setMediaType, "tvshowtitle": tag.setTvShowTitle,
            "dateadded": tag.setDateAdded,
        }
        for k, fn in setters.items():
            if info.get(k):
                fn(info[k])
        if info.get("year"):
            tag.setYear(int(info["year"]))
        if info.get("genre"):
            tag.setGenres(list(info["genre"]))
        if info.get("country"):
            tag.setCountries(list(info["country"]))
        if info.get("director"):
            tag.setDirectors(list(info["director"]))
        if info.get("duration"):
            tag.setDuration(int(info["duration"]))
        if info.get("season") is not None and info.get("mediatype") in ("season", "episode"):
            tag.setSeason(int(info["season"]))
        if info.get("episode"):
            tag.setEpisode(int(info["episode"]))
        if info.get("rating"):
            tag.setRating(float(info["rating"]), int(info.get("votes") or 0),
                          info.get("rating_type") or "csfd", True)
        if cast:
            tag.setCast([xbmc.Actor(name) for name in cast])
    else:
        data = dict((k, v) for k, v in info.items() if k not in ("rating_type",) and v)
        if "genre" in data:
            data["genre"] = list(data["genre"])
        li.setInfo("video", data)
        if info.get("rating"):
            li.setRating(info.get("rating_type") or "csfd", float(info["rating"]),
                         int(info.get("votes") or 0), True)
        if cast:
            li.setCast([{"name": n} for n in cast])


def _art(li, poster="", thumb="", fanart=""):
    art = {"icon": ICON, "fanart": fanart or FANART}
    if poster:
        art.update({"poster": poster, "thumb": poster})
    elif thumb:
        art.update({"thumb": thumb, "poster": thumb})
    else:
        art["thumb"] = ICON
    if thumb:
        art["landscape"] = thumb
    li.setArt(art)


def _meta_info(meta, mediatype):
    rating = meta.get("rating") or 0
    return {
        "title": _display_title(meta), "originaltitle": meta.get("orig_title") or "",
        "year": _display_year(meta), "genre": meta.get("genres") or [],
        "country": meta.get("countries") or [], "director": meta.get("directors") or [],
        "rating": rating / 10.0 if rating else 0, "votes": meta.get("votes") or 0,
        "rating_type": meta.get("rating_source") or "csfd",
        "mediatype": mediatype,
    }


def _meta_context(meta, collection_id=None):
    key = meta["key"]
    items = [
        (_(30373), "RunPlugin(%s)" % url_for("tmdb_repair", key=key)),
        (_(30300), "RunPlugin(%s)" % url_for("meta_assign", key=key)),
        (_(30301), "RunPlugin(%s)" % url_for("meta_refresh", key=key)),
        (_(30128), "RunPlugin(%s)" % url_for("collection_add", target=key)),
    ]
    if collection_id:
        items.append((_(30129), "RunPlugin(%s)" % url_for("collection_remove", cid=collection_id,
                                                           target=key)))
    if meta.get("first_video"):
        items.append((_(30302), "RunPlugin(%s)" % url_for("video_edit", vid=meta["first_video"])))
    return items


def _video_context(video):
    vid = video["id"]
    items = []
    if video.get("last_played"):
        items.append((_(30138), "RunPlugin(%s)" % url_for("history_remove", vid=vid)))
    return items + [
        (_(30325), "RunPlugin(%s)" % url_for("video_info", vid=vid)),
        (_(30302), "RunPlugin(%s)" % url_for("video_edit", vid=vid)),
        (_(30304) if video.get("hidden") else _(30303),
         "RunPlugin(%s)" % url_for("video_hide", vid=vid, hide=0 if video.get("hidden") else 1)),
        (_(30305), "RunPlugin(%s)" % url_for("video_delete", vid=vid)),
    ]


def _version_label(video):
    parts = [p for p in (video.get("lang"), video.get("quality"), video.get("size")) if p]
    return " · ".join(parts)


def add_movie(meta, collection_id=None, repair=False):
    year = _display_year(meta)
    label = _display_title(meta) + (" (%d)" % year if year else "")
    count = meta.get("video_count") or 1
    langs = ", ".join(x for x in (meta.get("langs") or "").split(",") if x)
    extra = [langs]
    if count > 1:
        extra.append(_(30133) % count)
    li = xbmcgui.ListItem(label)
    info = _meta_info(meta, "movie")
    info["plot"] = _plot(meta, extra)
    info["duration"] = (meta.get("runtime") or 0) * 60 or meta.get("duration") or 0
    if meta.get("added_at"):
        info["dateadded"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(meta["added_at"]))
    _set_info(li, info, meta.get("cast"))
    _art(li, meta.get("poster"), meta.get("thumb"), meta.get("fanart"))
    li.addContextMenuItems(_meta_context(meta, collection_id))
    if repair:
        xbmcplugin.addDirectoryItem(HANDLE, url_for("repair_title", key=meta["key"]), li, True)
    elif count == 1:
        li.setProperty("IsPlayable", "true")
        _apply_playback(li, meta["first_video"])
        xbmcplugin.addDirectoryItem(HANDLE, url_for("play", vid=meta["first_video"]), li, False)
    else:
        xbmcplugin.addDirectoryItem(HANDLE, url_for("versions", key=meta["key"]), li, True)


def add_show(meta, collection_id=None, repair=False):
    year = _display_year(meta)
    label = _display_title(meta) + (" (%d)" % year if year else "")
    li = xbmcgui.ListItem(label)
    info = _meta_info(meta, "tvshow")
    info["tvshowtitle"] = _display_title(meta)
    info["plot"] = _plot(meta, [_(30133) % (meta.get("video_count") or 0)])
    _set_info(li, info, meta.get("cast"))
    _art(li, meta.get("poster"), meta.get("thumb"), meta.get("fanart"))
    li.addContextMenuItems(_meta_context(meta, collection_id))
    xbmcplugin.addDirectoryItem(HANDLE, url_for("repair_title" if repair else "show", key=meta["key"]), li, True)


def add_video(video, meta=None, label=None, mediatype="video", progress=""):
    meta = meta or {}
    if label is None:
        label = video["raw_title"]
    li = xbmcgui.ListItem(label)
    info = {"title": label, "mediatype": mediatype, "duration": video.get("duration") or 0}
    extra = [progress, _version_label(video), "%s: %s" % (_(30330), video["raw_title"])]
    if meta:
        info.update(_meta_info(meta, mediatype))
        info["title"] = label
        info["plot"] = _plot(meta, extra)
    else:
        info["plot"] = "\n".join([x for x in extra if x] + [video.get("description") or ""])
    if mediatype == "episode":
        info["tvshowtitle"] = _display_title(meta) if meta else video["title"]
        info["season"] = video.get("season") or 0
        info["episode"] = video.get("episode") or 0
    if video.get("added_at"):
        info["dateadded"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(video["added_at"]))
    _set_info(li, info, meta.get("cast") if meta else None)
    _art(li, meta.get("poster") if meta else "", video.get("thumb"), meta.get("fanart") if meta else "")
    li.setProperty("IsPlayable", "true")
    _apply_playback(li, video["id"])
    li.addContextMenuItems(_video_context(video))
    xbmcplugin.addDirectoryItem(HANDLE, url_for("play", vid=video["id"]), li, False)


def add_dir(label, action, icon="", context=None, **params):
    li = xbmcgui.ListItem(label)
    li.setArt({"icon": icon or "DefaultFolder.png", "thumb": icon or "DefaultFolder.png",
               "fanart": FANART})
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(action, **params), li, True)


def add_action(label, action, icon="", **params):
    li = xbmcgui.ListItem(label)
    li.setArt({"icon": icon or "DefaultAddonService.png", "thumb": icon or "DefaultAddonService.png",
               "fanart": FANART})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(action, **params), li, False)


def end(content=None, sort=None, cache=True):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    for s in sort or [xbmcplugin.SORT_METHOD_NONE]:
        xbmcplugin.addSortMethod(HANDLE, s)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


MOVIE_SORTS = [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE,
               xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING,
               xbmcplugin.SORT_METHOD_DATEADDED, xbmcplugin.SORT_METHOD_GENRE]


# ---------------------------------------------------------------------------
# Obrazovky
# ---------------------------------------------------------------------------

def root(params):
    with open_library() as lib:
        empty = lib.count_videos() == 0
    add_dir(_(30360), "in_progress", "DefaultInProgressShows.png")
    if make_tmdb().enabled:
        add_dir(_(30390), "tmdb_titles", "DefaultMovies.png", kind="movie", category="popular")
    add_dir(_(30361), "my_videos_menu", "DefaultVideo.png")
    add_dir(_(30362), "tmdb_catalog", "DefaultMovies.png")
    add_dir(_(30102), "search_menu", "DefaultAddonsSearch.png")
    add_dir(_(30103), "collections", "DefaultSets.png")
    add_dir(_(30106), "tools", "DefaultAddonProgram.png")
    end(cache=False)
    if empty and not params.get("quiet"):
        notify(_(30132), time_ms=8000)


def my_videos_menu(params):
    add_dir(_(30100), "movies_menu", "DefaultMovies.png")
    add_dir(_(30101), "shows_menu", "DefaultTVShows.png")
    add_dir(_(30104), "recent", "DefaultRecentlyAddedMovies.png")
    add_dir(_(30134), "all_videos", "DefaultVideo.png")
    add_dir(_(30137), "played", "DefaultRecentlyAddedEpisodes.png")
    end()


def tmdb_catalog(params):
    add_dir(_(30374), "watchlist", "DefaultFavourites.png")
    if not make_tmdb().enabled:
        notify(_(30355), time_ms=8000)
        add_action(_(30356), "settings")
    else:
        add_dir(_(30100), "tmdb_categories", "DefaultMovies.png", kind="movie")
        add_dir(_(30101), "tmdb_categories", "DefaultTVShows.png", kind="tv")
    end(cache=False)


def tmdb_categories(params):
    kind = params.get("kind", "movie")
    add_dir(_(30351), "tmdb_titles", kind=kind, category="popular")
    add_dir(_(30352), "tmdb_titles", kind=kind, category="top_rated")
    add_dir(_(30353 if kind == "movie" else 30354), "tmdb_titles", kind=kind,
            category="upcoming" if kind == "movie" else "on_the_air")
    add_dir(_(30109), "tmdb_filters", kind=kind, filter_by="genre")
    add_dir(_(30357), "tmdb_filters", kind=kind, filter_by="year")
    end()


def tmdb_filters(params):
    kind = params.get("kind", "movie")
    try:
        if params.get("filter_by") == "genre":
            for genre in make_tmdb().genres(kind):
                add_dir(genre["name"], "tmdb_titles", kind=kind, category="discover", genre=genre["id"])
        else:
            for year in range(date.today().year, 1873, -1):
                add_dir(str(year), "tmdb_titles", kind=kind, category="discover", year=year)
    except TmdbError as e:
        notify(str(e), time_ms=8000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    end()


def tmdb_titles(params):
    kind = params.get("kind", "movie")
    category = params.get("category", "popular")
    genre = params.get("genre", "")
    year = params.get("year", "")
    allowed = ("popular", "top_rated", "discover", "upcoming" if kind == "movie" else "on_the_air")
    try:
        page = int(params.get("page", 1))
        if kind not in ("movie", "tv") or category not in allowed or not 1 <= page <= 500:
            raise ValueError(_(30358))
        titles, total_pages = make_tmdb().browse(kind, category, page, genre=genre, year=year)
    except (ValueError, TmdbError) as e:
        notify(str(e), time_ms=8000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for item in titles:
        add_tmdb_title(item, kind)
    if page < total_pages:
        add_dir(_(30341), "tmdb_titles", kind=kind, category=category, page=page + 1,
                genre=genre, year=year)
    if not titles:
        notify(_(30121))
    end("movies" if kind == "movie" else "tvshows", cache=False)


def add_tmdb_title(item, kind):
    title = item.get("title") or item.get("name")
    if not title or not item.get("id"):
        return
    original = item.get("original_title") or item.get("original_name") or title
    release = item.get("release_date") or item.get("first_air_date") or ""
    released_year = int(release[:4]) if release[:4].isdigit() else 0
    li = xbmcgui.ListItem("%s (%d)" % (title, released_year) if released_year else title)
    _set_info(li, {"title": title, "originaltitle": original, "year": released_year,
                   "plot": item.get("overview") or "", "rating": item.get("vote_average") or 0,
                   "votes": item.get("vote_count") or 0, "rating_type": "tmdb",
                   "mediatype": "movie" if kind == "movie" else "tvshow"})
    poster = item.get("poster_path")
    backdrop = item.get("backdrop_path")
    _art(li, poster=IMG + "w500" + poster if poster else "",
         fanart=IMG + "w1280" + backdrop if backdrop else "")
    detail_url = url_for("tmdb_title", kind=kind, tmdb_id=item["id"])
    args = {"kind": kind, "tmdb_id": item["id"], "title": title, "original": original,
            "year": released_year, "poster": IMG + "w500" + poster if poster else ""}
    context = [(_(30391), "Container.Update(%s)" % detail_url),
               (_(30375), "RunPlugin(%s)" % url_for("watchlist_change", **args))]
    if original != title:
        context.append((_(30359), "Container.Update(%s)" % url_for("provider_search", q=original)))
    li.addContextMenuItems(context)
    target = (url_for("tmdb_movie_versions", tmdb_id=item["id"], title=title, original=original,
                      year=released_year) if kind == "movie" else detail_url)
    xbmcplugin.addDirectoryItem(HANDLE, target, li, True)


def _movie_result_key(video, parsed, title, original, year):
    # Handles punctuation and bilingual names in either order. Use the raw
    # filename to detect trailers even when parse() strips everything after the year.
    localized, original = normalize(title), normalize(original)
    aliases = {name.strip() for name in (localized, original, localized + " " + original,
                                         original + " " + localized) if name.strip()}
    name = normalize(parsed["title"])
    extras = {"trailer", "teaser", "ukazka", "upoutavka"}
    raw_words = set(normalize(video["title"]).split())
    title_words = set(localized.split()) | set(original.split())
    preview = bool(extras & (raw_words - title_words))
    exact = name in aliases and parsed["kind"] == "movie"
    year_matches = not year or parsed["year"] in (0, year)
    rank = 0 if exact and year_matches else 1
    version = _provider_version(video, parsed)
    return (preview, rank, _version_score(version))


def tmdb_movie_versions(params):
    title = params.get("title", "").strip()
    original = params.get("original", "").strip()
    query = params.get("q", "").strip() or title
    if not query:
        end(cache=False)
        return
    try:
        tmdb_id = int(params.get("tmdb_id") or 0)
        year = int(params.get("year") or 0)
        page = int(params.get("page") or 1)
    except ValueError:
        end(cache=False)
        return
    args = {key: params.get(key) for key in ("tmdb_id", "title", "original", "year")}
    local_ids = set()
    if page == 1:
        with open_library() as lib:
            match = _library_match(lib.movies(), {"tmdb_id": tmdb_id, "title": title,
                                                   "orig_title": original, "year": year})
            local = lib.videos_for_meta(match["key"]) if match else []
        for video in sorted(local, key=_version_score):
            label = _version_label(video) or video["raw_title"]
            add_video(video, match, label="%s · %s" % (_(30392), label), mediatype="movie")
            local_ids.add(provider.video_key(video["id"]))
    videos, cursor = [], None
    try:
        videos, cursor = provider.search_catalog(make_client(), query, page, params.get("cursor", ""))
    except provider.LoginError:
        notify(_(30368), time_ms=8000)
        add_action(_(30356), "settings")
    except (ValueError, provider.ProviderError, provider.RateLimited) as e:
        notify(_(30369) % e, time_ms=8000)
    else:
        versions = []
        for result in videos:
            parsed = parse(result["title"])
            versions.append((_movie_result_key(result, parsed, title, original, year),
                             _provider_version(result, parsed)))
        for sort_key, video in sorted(versions, key=lambda item: item[0]):
            preview, rank = sort_key[:2]
            identity = provider.video_key(video["id"])
            if identity in local_ids:
                continue
            local_ids.add(identity)
            label = _version_label(video) if not preview and rank == 0 else ""
            # A descriptive second line plus the original filename help distinguish versions
            # that happen to have the same language, resolution and file size.
            add_provider_result(video, label or video["title"])
        if not videos and not local_ids and not cursor:
            notify(_(30370))
    if cursor:
        add_dir(_(30341), "tmdb_movie_versions", q=query, page=page + 1, cursor=cursor, **args)
    if page == 1 and original and normalize(original) != normalize(query):
        add_dir(_(30359), "tmdb_movie_versions", q=original, **args)
    end("videos", cache=False)


def _library_match(items, detail):
    exact = [item for item in items if item.get("tmdb_id") == detail["tmdb_id"]]
    if exact:
        return exact[0] if len(exact) == 1 else None
    titles = {normalize(t) for t in (detail["title"], detail["orig_title"]) if t}
    if not detail["year"] or not titles:
        return None
    matches = [
        item for item in items
        if not item.get("tmdb_id") and _display_year(item) == detail["year"]
        and titles.intersection(normalize(t) for t in (_display_title(item), item.get("orig_title")) if t)
    ]
    return matches[0] if len(matches) == 1 else None


def tmdb_title(params):
    want_series = params.get("kind") == "tv"
    try:
        tmdb_id = int(params.get("tmdb_id", 0))
        if tmdb_id < 1:
            raise ValueError(_(30358))
        client = make_tmdb()
        if not client.enabled:
            tmdb_catalog(params)
            return
        detail = client.details(tmdb_id, want_series)
    except (ValueError, TmdbError) as e:
        notify(str(e), time_ms=8000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    detail["rating_source"] = "tmdb"
    with open_library() as lib:
        match = _library_match(lib.shows() if want_series else lib.movies(), detail)
        videos = lib.videos_for_meta(match["key"]) if match and not want_series else []
        kind = "tv" if want_series else "movie"
        saved = lib.watchlist_has(kind, tmdb_id)

    def add_option(label, action, folder=True, **route_params):
        li = xbmcgui.ListItem(label)
        info = _meta_info(detail, "tvshow" if want_series else "movie")
        info["title"] = label
        info["plot"] = detail["plot"]
        _set_info(li, info, detail["cast"])
        _art(li, poster=detail["poster"], fanart=detail["fanart"])
        if not folder:
            li.setProperty("IsPlayable", "true")
            _apply_playback(li, route_params["vid"])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action, **route_params), li, folder)

    if match and want_series:
        add_option(_(30364), "show", key=match["key"])
    elif len(videos) == 1:
        add_option(_(30363), "play", folder=False, vid=videos[0]["id"])
    elif videos:
        add_option(_(30363), "versions", key=match["key"])
    title = detail["title"] or detail["orig_title"]
    if title:
        if want_series:
            add_option(_(30340), "provider_search", q=title)
        else:
            add_option(_(30340), "tmdb_movie_versions", title=title, original=detail["orig_title"],
                       year=detail["year"], tmdb_id=tmdb_id)
    if detail["orig_title"] and detail["orig_title"] != title:
        add_option(_(30359), "provider_search", q=detail["orig_title"])
    add_action(_(30376 if saved else 30375), "watchlist_change", kind=kind, tmdb_id=tmdb_id,
               remove=int(saved), title=title, year=detail["year"], poster=detail["poster"])
    end("tvshows" if want_series else "movies", cache=False)


def watchlist(params):
    with open_library() as lib:
        entries = lib.watchlist()
    for entry in entries:
        name = entry["title"]
        if entry["year"]:
            name += " (%d)" % entry["year"]
        item = xbmcgui.ListItem(name)
        _art(item, poster=entry["poster"])
        args = {"kind": entry["kind"], "tmdb_id": entry["tmdb_id"]}
        item.addContextMenuItems([(_(30376), "RunPlugin(%s)" % url_for("watchlist_change", remove=1, **args))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for("tmdb_title", **args), item, True)
    if not entries:
        notify(_(30377))
    end("videos", cache=False)


def watchlist_change(params):
    kind = params.get("kind")
    try:
        tmdb_id = int(params.get("tmdb_id", 0))
        year = int(params.get("year", 0))
    except ValueError:
        return
    if kind not in ("movie", "tv") or tmdb_id <= 0:
        return
    with open_library() as lib:
        if params.get("remove") == "1":
            lib.watchlist_remove(kind, tmdb_id)
        elif params.get("title"):
            poster = params.get("poster", "")
            lib.watchlist_add(kind, tmdb_id, params["title"], year, poster if poster.startswith(IMG) else "")
    xbmc.executebuiltin("Container.Refresh")


def tmdb_search(params):
    query = params.get("q", "").strip()
    client = make_tmdb()
    if not client.enabled:
        notify(_(30355), time_ms=8000)
        add_action(_(30356), "settings")
        end(cache=False)
        return
    try:
        page = int(params.get("page", 1))
        if not query or not 1 <= page <= 500:
            raise ValueError(_(30358))
        titles, total_pages = client.search_titles(query, page)
    except (TmdbError, ValueError) as e:
        notify(str(e), time_ms=8000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for item in titles:
        add_tmdb_title(item, item["media_type"])
    if page < total_pages:
        add_dir(_(30341), "tmdb_search", q=query, page=page + 1)
    elif not titles:
        notify(_(30121))
    end("videos", cache=False)


def movies_menu(params):
    add_dir(_(30107), "movies", "DefaultMovies.png", order="title")
    add_dir(_(30104), "movies", "DefaultRecentlyAddedMovies.png", order="added")
    add_dir(_(30108), "movies", "DefaultMovieTitle.png", order="rating")
    add_dir(_(30109), "movie_genres", "DefaultGenre.png")
    add_dir(_(30110), "movie_decades", "DefaultYear.png")
    add_dir(_(30111), "movie_countries", "DefaultCountry.png")
    add_dir(_(30112), "movie_ratings", "DefaultMovieTitle.png")
    end()


def movies(params):
    order = params.get("order", "title")
    with open_library() as lib:
        items = lib.movies(genre=params.get("genre"), country=params.get("country"),
                           year_from=int(params["year_from"]) if params.get("year_from") else None,
                           year_to=int(params["year_to"]) if params.get("year_to") else None,
                           min_rating=int(params["min_rating"]) if params.get("min_rating") else None,
                           order=order)
    for m in items:
        add_movie(m)
    end("movies", MOVIE_SORTS)


def movie_genres(params):
    kind = params.get("kind", "movie")
    with open_library() as lib:
        genres = lib.genres(kind)
    for g, count in genres:
        if kind == "movie":
            add_dir("%s (%d)" % (g, count), "movies", "DefaultGenre.png", genre=g, order="title")
        else:
            add_dir("%s (%d)" % (g, count), "shows", "DefaultGenre.png", genre=g, order="title")
    end()


def movie_decades(params):
    with open_library() as lib:
        decades = lib.decades("movie")
    for d, count in decades:
        add_dir("%d–%d (%d)" % (d, d + 9, count), "movies", "DefaultYear.png", year_from=d,
                year_to=d + 9, order="year")
    end()


def movie_countries(params):
    with open_library() as lib:
        countries = lib.countries("movie")
    for c, count in countries:
        add_dir("%s (%d)" % (c, count), "movies", "DefaultCountry.png", country=c, order="title")
    end()


def movie_ratings(params):
    kind = params.get("kind", "movie")
    for r in (90, 80, 70, 60, 50):
        add_dir(_(30135) % r, "movies" if kind == "movie" else "shows", "DefaultMovieTitle.png",
                min_rating=r, order="rating")
    end()


def versions(params):
    with open_library() as lib:
        meta = lib.get_meta(params["key"])
        videos = lib.videos_for_meta(params["key"])
    for v in sorted(videos, key=_version_score):
        label = _version_label(v) or v["raw_title"]
        add_video(v, meta, label="%s – %s" % (_display_title(meta), label), mediatype="movie")
    end("movies")


def shows_menu(params):
    add_dir(_(30113), "shows", "DefaultTVShows.png", order="title")
    add_dir(_(30104), "shows", "DefaultRecentlyAddedEpisodes.png", order="added")
    add_dir(_(30108), "shows", "DefaultTVShowTitle.png", order="rating")
    add_dir(_(30109), "movie_genres", "DefaultGenre.png", kind="show")
    add_dir(_(30112), "movie_ratings", "DefaultTVShowTitle.png", kind="show")
    end()


def shows(params):
    with open_library() as lib:
        items = lib.shows(genre=params.get("genre"),
                          min_rating=int(params["min_rating"]) if params.get("min_rating") else None,
                          order=params.get("order", "title"))
    for m in items:
        add_show(m)
    end("tvshows", MOVIE_SORTS)


def _season_label(season):
    return _(30115) if not season else _(30114) % season


def _season_summary(videos, watched):
    available = sorted({v["episode"] for v in videos if v["episode"] > 0})
    completed = {v["episode"] for v in videos if v["episode"] > 0 and v["id"] in watched}
    text = _(30378) % (len(available), len(completed))
    gaps = (number for previous, current in zip([0] + available, available)
            for number in range(previous + 1, current))
    missing = list(islice(gaps, 13))
    if missing:
        numbers = ", ".join(str(number) for number in missing[:12])
        text += "\n" + _(30379) % (numbers + ("…" if len(missing) > 12 else ""))
    return text


def show(params):
    key = params["key"]
    with open_library() as lib:
        meta = lib.get_meta(key)
        videos = lib.videos_for_meta(key)
        watched = lib.watched(v["id"] for v in videos)
    if meta is None:
        end()
        return
    seasons = {}
    for video in videos:
        seasons.setdefault(video["season"], []).append(video)
    for number, entries in seasons.items():
        title = _season_label(number)
        summary = _season_summary(entries, watched)
        li = xbmcgui.ListItem("%s · %s" % (title, summary.split("\n")[0]))
        info = _meta_info(meta, "season")
        info.update({"title": title, "season": number, "tvshowtitle": _display_title(meta),
                     "plot": _plot(meta, [summary])})
        _set_info(li, info)
        _art(li, meta.get("poster"), "", meta.get("fanart"))
        li.addContextMenuItems(_meta_context(meta))
        xbmcplugin.addDirectoryItem(HANDLE, url_for("season", key=key, season=number), li, True)
    end("seasons", cache=False)


def season(params):
    key = params["key"]
    number = int(params.get("season") or 0)
    requested = int(params.get("episode") or 0)
    with open_library() as lib:
        meta = lib.get_meta(key)
        videos = lib.videos_for_meta(key, season=number)
        watched = lib.watched(v["id"] for v in videos)
    if requested:
        for video in sorted((v for v in videos if v["episode"] == requested), key=_version_score):
            add_video(video, meta, label=_version_label(video) or video["raw_title"], mediatype="episode")
        end("episodes", cache=False)
        return

    groups = {}
    for video in videos:
        groups.setdefault(video["episode"] or video["id"], []).append(video)
    if videos:
        summary = _season_summary(videos, watched)
        add_action(summary.replace("\n", " · "), "season_status", key=key, season=number)
    for group in groups.values():
        video = group[0]
        episode = video["episode"]
        label = "%dx%02d" % (number, episode) if episode else video["raw_title"]
        if len(group) == 1:
            add_video(video, meta, label=label, mediatype="episode")
            continue
        li = xbmcgui.ListItem("%s · %s" % (label, _(30133) % len(group)))
        info = _meta_info(meta or {}, "episode")
        info.update({"title": label, "season": number, "episode": episode, "plot": summary})
        _set_info(li, info)
        _art(li, (meta or {}).get("poster"), video["thumb"], (meta or {}).get("fanart"))
        xbmcplugin.addDirectoryItem(HANDLE, url_for("season", key=key, season=number, episode=episode), li, True)
    end("episodes", cache=False)


def season_status(params):
    with open_library() as lib:
        videos = lib.videos_for_meta(params["key"], season=int(params.get("season") or 0))
        watched = lib.watched(v["id"] for v in videos)
    text_viewer(_season_label(int(params.get("season") or 0)), _season_summary(videos, watched))


def recent(params):
    _video_list(lambda lib: lib.recent_videos(limit=100),
                [xbmcplugin.SORT_METHOD_DATEADDED, xbmcplugin.SORT_METHOD_LABEL])


def all_videos(params):
    """Všechna videa z účtu v jednom seznamu (filmy i díly), řaditelná."""
    _video_list(lambda lib: lib.all_videos(),
                [xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, xbmcplugin.SORT_METHOD_DATEADDED,
                 xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING])


def in_progress(params):
    with open_library() as lib:
        entries = lib.history_videos(in_progress=True)
        recent = lib.history_videos()
        watched = lib.watched()
        seen = set()
        for video in recent:
            key = video["meta_key"]
            if video["kind"] != "episode" or not key or key in seen:
                continue
            seen.add(key)
            if (video["id"] not in watched or not video["episode"]
                    or not video["season"]):
                continue
            episodes = [v for v in lib.videos_for_meta(key) if v["season"] and v["episode"]]
            completed = {(v["season"], v["episode"]) for v in episodes if v["id"] in watched}
            current = (video["season"], video["episode"])
            following = next((v for v in episodes if (v["season"], v["episode"]) > current
                              and (v["season"], v["episode"]) not in completed), None)
            if following and not any(v["meta_key"] == key for v in entries):
                entries.append(dict(following, next_episode=True, last_played=video["last_played"]))
        metas = {key: lib.get_meta(key) or {} for key in {v["meta_key"] for v in entries}}

    for video in sorted(entries, key=lambda v: v["last_played"], reverse=True):
        meta = metas[video["meta_key"]]
        title = _display_title(meta) or video["title"] or video["raw_title"]
        is_episode = video["kind"] == "episode"
        if is_episode:
            title = "%s %dx%02d" % (title, video["season"], video["episode"])
        if video.get("next_episode"):
            label = _(30365) % title
            progress = ""
        else:
            position, total = video["position"], video["total"]
            progress = _(30366) % (int(100 * position / total), max(1, int((total - position + 59) // 60)))
            label = "%s · %s" % (title, progress)
        add_video(video, meta, label=label, mediatype="episode" if is_episode else "movie", progress=progress)
    if not entries:
        notify(_(30367))
    end("videos", cache=False)


def played(params):
    _video_list(lambda lib: lib.history_videos(), [xbmcplugin.SORT_METHOD_UNSORTED])


def history_remove(params):
    with open_library() as lib:
        lib.remove_history(params.get("vid"))
    xbmc.executebuiltin("Container.Refresh")


def history_clear(params):
    if yesno(_(30238)):
        with open_library() as lib:
            lib.remove_history()


def diagnostics(params):
    """Uloží stránky účtu (bez přihlašovacích údajů) pro ladění parseru."""
    if not _require_credentials():
        return
    folder = xbmcgui.Dialog().browse(3, _(30235), "files")
    if not folder:
        return
    try:
        pages = provider.diagnostics(make_client())
    except provider.ProviderError as e:
        ok(_(30328) % e)
        return
    secrets = [setting("username"), setting("password")]
    stamp = time.strftime("%Y%m%d-%H%M%S")
    sep = "\\" if "\\" in folder and "/" not in folder else "/"
    base = folder.rstrip("/\\") + sep + "diagnostika-%s-%s" % (ADDON_ID, stamp)
    xbmcvfs.mkdirs(base)
    for name, content in pages.items():
        f = xbmcvfs.File(base + sep + name, "w")
        try:
            f.write(catalog.sanitize(content, secrets))
        finally:
            f.close()
    ok(_(30236) % base)


def _video_list(load, sorts):
    with open_library() as lib:
        videos = load(lib)
        metas = dict((m["key"], m) for m in (lib.get_meta(k) for k in set(v["meta_key"] for v in videos)) if m)
    for v in videos:
        meta = metas.get(v["meta_key"]) or {}
        if v["kind"] == "episode":
            label = "%s %dx%02d" % (_display_title(meta) or v["title"], v["season"], v["episode"])
        else:
            year = _display_year(meta) if meta else v["year"]
            label = (_display_title(meta) or v["title"]) + (" (%d)" % year if year else "")
        add_video(v, meta, label=label, mediatype="episode" if v["kind"] == "episode" else "movie")
    end("videos", sorts)


def unmatched(params):
    with open_library() as lib:
        items = lib.unmatched()
    for m in items:
        if m["kind"] == "show":
            add_show(m, repair=True)
        else:
            add_movie(m, repair=True)
    add_dir("[I]%s[/I]" % _(30131), "hidden", "DefaultVideoDeleted.png")
    end("videos")


def hidden(params):
    with open_library() as lib:
        videos = lib.hidden_videos()
    for v in videos:
        add_video(v)
    end("videos")


# --- hledání ---------------------------------------------------------------

def search_menu(params):
    add_dir("[B]%s[/B]" % _(30117), "search", "DefaultAddonsSearch.png")
    with open_library() as lib:
        history = lib.search_history()
    for q in history:
        add_dir(q, "search", "DefaultAddonsSearch.png",
                context=[(_(30122), "RunPlugin(%s)" % url_for("search_delete", q=q))], q=q)
    end(cache=False)


def search(params):
    query = params.get("q")
    if not query:
        # klávesnice jen jednou – výsledky mají vlastní adresu, aby se po návratu
        # zpět neotevírala znovu
        query = keyboard(_(30118))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        if query:
            xbmc.executebuiltin("Container.Update(%s)" % url_for("search", q=query))
        return
    with open_library() as lib:
        lib.add_search(query)
        found_movies, found_shows = lib.search(query)
    for m in found_movies:
        add_movie(m)
    for m in found_shows:
        add_show(m)
    if not found_movies and not found_shows:
        notify(_(30389))
    add_dir(_(30340), "provider_search", "DefaultAddonsSearch.png", q=query)
    add_dir(_(30372), "tmdb_search", "DefaultAddonsSearch.png", q=query)
    end("videos", cache=False)


def provider_search(params):
    if not hasattr(provider, "search_catalog"):
        end(cache=False)
        return
    query = params.get("q", "").strip()
    if not query:
        query = (keyboard(_(30340)) or "").strip()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        if query:
            xbmc.executebuiltin("Container.Update(%s)" % url_for("provider_search", q=query))
        return
    try:
        page = int(params.get("page", 1))
        videos, cursor = provider.search_catalog(make_client(), query, page, params.get("cursor", ""))
    except provider.LoginError:
        notify(_(30368), time_ms=8000)
        add_action(_(30356), "settings")
        end(cache=False)
        return
    except (ValueError, provider.ProviderError, provider.RateLimited) as e:
        notify(_(30369) % e, time_ms=8000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    groups = {}
    for video in videos:
        parsed = parse(video["title"])
        title = normalize(parsed["title"])
        if title and parsed["year"] and (parsed["kind"] == "movie" or parsed["episode"]):
            key = (parsed["kind"], title, parsed["year"], parsed["season"], parsed["episode"])
        else:
            key = (video["id"],)
        groups.setdefault(key, []).append((video, parsed))
    selected = params.get("group")
    for group in groups.values():
        first, parsed = group[0]
        if selected:
            if any(video["id"] == selected for video, _ in group):
                for video, parts in sorted(group, key=lambda pair: _version_score(_provider_version(*pair))):
                    add_provider_result(video, _version_label(_provider_version(video, parts)) or video["title"])
                end("videos", cache=False)
                return
        elif len(group) == 1:
            add_provider_result(first)
        else:
            if parsed["kind"] == "episode":
                label = "%s %dx%02d (%d)" % (parsed["title"], parsed["season"], parsed["episode"], parsed["year"])
            else:
                label = "%s (%d)" % (parsed["title"], parsed["year"])
            add_dir("%s · %s" % (label, _(30133) % len(group)), "provider_search", first["thumb"],
                    q=query, page=page, cursor=params.get("cursor"), group=first["id"])
    if selected:
        notify(_(30370))
        end("videos", cache=False)
        return
    if cursor:
        add_dir(_(30341), "provider_search", q=query, page=page + 1, cursor=cursor)
    if not videos and not cursor:
        notify(_(30370))
    end("videos", cache=False)


def _provider_version(video, parsed):
    return {**video, "lang": parsed["lang"], "quality": video.get("quality") or parsed["quality"]}


def add_provider_result(video, label=None):
    li = xbmcgui.ListItem(label or video["title"])
    description = "\n".join(filter(None, (_version_label(video), video["title"])))
    _set_info(li, {"title": label or video["title"], "mediatype": "video", "duration": video["duration"],
                   "plot": description})
    _art(li, thumb=video["thumb"])
    li.setProperty("IsPlayable", "true")
    save_url = url_for("provider_save", vid=video["id"], title=video["title"])
    li.addContextMenuItems([(_(30342), "RunPlugin(%s)" % save_url)])
    xbmcplugin.addDirectoryItem(HANDLE, url_for("play", vid=video["id"]), li, False)


def provider_save(params):
    if not hasattr(provider, "search_catalog"):
        return
    try:
        vid = params.get("vid", "")
        if provider.find_video_id(provider.video_page_url(vid)):
            _import([(vid, params.get("title", ""))])
    except provider.ProviderError as e:
        notify(_(30328) % e)


def search_delete(params):
    with open_library() as lib:
        lib.delete_search(params["q"])
    xbmc.executebuiltin("Container.Refresh")


# --- kolekce ---------------------------------------------------------------

def collections(params):
    add_action("[B]%s[/B]" % _(30123), "collection_new", "DefaultAddSource.png")
    with open_library() as lib:
        cols = lib.collections()
    for c in cols:
        ctx = [(_(30125), "RunPlugin(%s)" % url_for("collection_rename", cid=c["id"])),
               (_(30126), "RunPlugin(%s)" % url_for("collection_delete", cid=c["id"]))]
        add_dir("%s (%d)" % (c["name"], c["item_count"]), "collection", "DefaultSets.png", context=ctx,
                cid=c["id"])
    end(cache=False)


def collection(params):
    cid = int(params["cid"])
    with open_library() as lib:
        targets = lib.collection_targets(cid)
        keys = [t for t in targets if not t.startswith("v:")]
        movies_ = dict((m["key"], m) for m in lib.movies(keys=keys))
        shows_ = dict((m["key"], m) for m in lib.shows(keys=keys))
        videos = [lib.get_video(t[2:]) for t in targets if t.startswith("v:")]
    for t in keys:
        if t in movies_:
            add_movie(movies_[t], collection_id=cid)
        elif t in shows_:
            add_show(shows_[t], collection_id=cid)
    for v in videos:
        if v:
            add_video(v)
    end("movies", MOVIE_SORTS, cache=False)


def collection_new(params):
    name = keyboard(_(30124))
    if not name:
        return None
    with open_library() as lib:
        cid = lib.create_collection(name)
    xbmc.executebuiltin("Container.Refresh")
    return cid


def collection_rename(params):
    cid = int(params["cid"])
    with open_library() as lib:
        current = next((c["name"] for c in lib.collections() if c["id"] == cid), "")
        name = keyboard(_(30125), current)
        if name:
            lib.rename_collection(cid, name)
    xbmc.executebuiltin("Container.Refresh")


def collection_delete(params):
    cid = int(params["cid"])
    with open_library() as lib:
        current = next((c["name"] for c in lib.collections() if c["id"] == cid), "")
        if yesno(_(30127) % current):
            lib.delete_collection(cid)
    xbmc.executebuiltin("Container.Refresh")


def collection_add(params):
    target = params["target"]
    with open_library() as lib:
        cols = lib.collections()
        names = ["[B]%s[/B]" % _(30123)] + [c["name"] for c in cols]
        idx = select(_(30128), names)
        if idx < 0:
            return
        if idx == 0:
            name = keyboard(_(30124))
            if not name:
                return
            cid = lib.create_collection(name)
        else:
            cid = cols[idx - 1]["id"]
            name = cols[idx - 1]["name"]
        lib.add_to_collection(cid, target)
    notify(_(30130) % name)


def collection_remove(params):
    with open_library() as lib:
        lib.remove_from_collection(int(params["cid"]), params["target"])
    xbmc.executebuiltin("Container.Refresh")


# --- nástroje --------------------------------------------------------------

def tools(params):
    with open_library() as lib:
        last = lib.get_kv("last_sync")
    last_text = _sync_time(int(last)) if last else _(30232)
    add_action(_(30231) % last_text, "stats", "DefaultIconInfo.png")
    add_dir(_(30105), "unmatched", "DefaultVideoDeleted.png")
    add_action(_(30200), "sync", "DefaultAddonService.png")
    add_action(_(30203), "enrich", "DefaultAddonInfoProvider.png")
    add_action(_(30202), "add_link", "DefaultAddSource.png")
    add_action(_(30201), "import_file", "DefaultFile.png")
    add_action(_(30206), "export_library", "DefaultAddonLibrary.png")
    add_action(_(30205), "account_status", "DefaultUser.png")
    add_action(_(30204), "refresh_all", "DefaultAddonInfoProvider.png")
    add_action(_(30237), "history_clear", "DefaultIconError.png")
    add_action(_(30234), "diagnostics", "DefaultIconInfo.png")
    add_action(_(30345), "backup_catalog", "DefaultAddonLibrary.png")
    add_action(_(30346), "restore_catalog", "DefaultAddonLibrary.png")
    add_action(_(30207), "clear_library", "DefaultIconError.png")
    add_action(_(30208), "settings", "DefaultAddonProgram.png")
    end(cache=False)


def _require_credentials():
    if not setting("username") or not setting("password"):
        ok(_(30222))
        ADDON.openSettings()
        return False
    return True


def _sync_time(timestamp):
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(timestamp))


def run_sync(background=False):
    """Synchronizace účtu + volitelně metadata. Použitelné i ze služby."""
    progress = Progress(_(30210), background=background)
    try:
        client = make_client()

        def on_progress(stage, pages, count):
            progress.update(min(95, pages * 5), _(30211) % (pages, count))
            return progress.cancelled()

        with open_library() as lib:
            stats = catalog.sync_account(
                client, lib, include_favorites=setting_bool("sync_favorites"),
                include_playlists=setting_bool("sync_playlists"),
                remove_missing=setting_bool("remove_missing"), progress=on_progress, log=log)
    finally:
        progress.close()
    log_info("sync: %s" % stats)
    msg = _(30212) % (stats["total"], stats["new"], stats["removed"])
    if stats["incomplete"] and not stats["cancelled"]:
        notify(_(30343) % stats["total"], time_ms=8000)
    elif not stats["cancelled"] and (not background or stats["new"] or stats["removed"]):
        notify("%s · %s" % (_sync_time(time.time()), msg), time_ms=7000)
    if setting_bool("auto_meta") and not stats["cancelled"]:
        run_enrich(statuses=("new",), background=background, quiet=True)
    return stats


def sync(params):
    if not _require_credentials():
        return
    try:
        run_sync()
    except provider.LoginError as e:
        ok(str(e))
    except provider.ProviderError as e:
        log_error("sync: %s" % e)
        ok(_(30328) % e)
    xbmc.executebuiltin("Container.Refresh")


def run_enrich(statuses=("new",), keys=None, background=False, quiet=False):
    use_csfd = setting_bool("use_csfd")
    tmdb = make_tmdb()
    with open_library() as lib:
        if keys:
            metas = [m for m in (lib.get_meta(k) for k in keys) if m]
        else:
            metas = lib.meta_to_fetch(statuses)
        if not metas:
            if not quiet:
                notify(_(30121))
            return None
        progress = Progress(_(30213), background=background)
        try:
            def on_progress(idx, total, title):
                progress.update(idx * 100 // max(1, total), _(30214) % (idx + 1, total, title))
                return progress.cancelled()
            stats = catalog.enrich(lib, metas, use_csfd=use_csfd, tmdb=tmdb, progress=on_progress, log=log)
        finally:
            progress.close()
    log_info("metadata: %s" % stats)
    if stats["csfd_blocked"]:
        if not tmdb.enabled and not background:
            ok(_(30216))
        else:
            log_info("ČSFD blokuje dotazy, použito TMDB")
    if stats["last_error"] and not stats["ok"] and not stats["csfd_blocked"] and not background:
        notify(_(30328) % stats["last_error"])
    if not (background and quiet) or stats["ok"]:
        notify(_(30215) % (stats["ok"], stats["csfd"], stats["tmdb"], stats["notfound"], stats["errors"]),
               time_ms=7000)
    return stats


def enrich(params):
    run_enrich(statuses=("new", "notfound", "error", "blocked"))
    xbmc.executebuiltin("Container.Refresh")


def refresh_all(params):
    if not yesno(_(30229)):
        return
    with open_library() as lib:
        keys = [m["key"] for m in lib.meta_to_fetch(("new", "ok", "notfound", "error", "blocked"))]
    run_enrich(keys=keys)
    xbmc.executebuiltin("Container.Refresh")


def add_link(params):
    text = keyboard(_(30217))
    if not text:
        return
    links = catalog.parse_link_lines(text)
    if not links:
        ok(_(30218))
        return
    _import(links)


def import_file(params):
    path = xbmcgui.Dialog().browse(1, _(30220), "files", ".txt|.csv|.m3u|.list")
    if not path:
        return
    f = xbmcvfs.File(path)
    try:
        content = f.read()
    finally:
        f.close()
    if isinstance(content, bytes):
        content = content.decode("utf-8", "replace")
    links = catalog.parse_link_lines(content)
    if not links:
        ok(_(30221))
        return
    _import(links)


def _import(links):
    progress = Progress(_(30201))
    try:
        def on_progress(idx, total, title):
            progress.update(idx * 100 // max(1, total), title)
            return progress.cancelled()
        with open_library() as lib:
            stats = catalog.import_links(make_client(), lib, links, progress=on_progress, log=log)
    finally:
        progress.close()
    notify(_(30219) % (stats["new"], stats["existing"]))
    if stats["new"] and setting_bool("auto_meta"):
        run_enrich(statuses=("new",), quiet=True)
    xbmc.executebuiltin("Container.Refresh")


def account_status(params):
    if not _require_credentials():
        return
    try:
        result, expiration = make_client().check_user()
    except provider.ProviderError as e:
        ok(_(30328) % e)
        return
    if result == provider.CHECK_PREMIUM:
        set_setting("premium_until", provider.premium_text(expiration))
        ok(_(30223) % provider.premium_text(expiration))
    elif result == provider.CHECK_NO_PREMIUM:
        set_setting("premium_until", "-")
        ok(_(30224))
    else:
        set_setting("premium_until", "")
        ok(_(30225))


def stats(params):
    with open_library() as lib:
        s = lib.stats()
        last = lib.get_kv("last_sync")
    last_text = _sync_time(int(last)) if last else _(30232)
    text_viewer(_(30209), (_(30230) % (s["videos"], s["movies"], s["shows"], s["with_rating"],
                                       s["unmatched"])) + "\n\n" + _(30231) % last_text)


def clear_library(params):
    if yesno(_(30226)):
        with open_library() as lib:
            lib.clear()
        xbmc.executebuiltin("Container.Refresh")


def backup_catalog(params):
    folder = xbmcgui.Dialog().browse(3, _(30345), "files")
    if not folder:
        return
    name = "%s-catalog-%s.json" % (ADDON_ID, time.strftime("%Y%m%d-%H%M%S"))
    destination = folder.rstrip("/\\") + "/" + name
    try:
        with open_library() as lib:
            data = json.dumps(lib.export_backup(ADDON_ID), ensure_ascii=False, allow_nan=False)
        file = xbmcvfs.File(destination, "w")
        try:
            if not file.write(data):
                raise OSError("Kodi could not write the backup")
        finally:
            file.close()
    except (OSError, ValueError, sqlite3.Error) as e:
        ok(_(30328) % e)
        return
    notify(_(30348) % destination, time_ms=8000)


def restore_catalog(params):
    path = xbmcgui.Dialog().browse(1, _(30346), "files", ".json")
    if not path or not yesno(_(30347)):
        return
    try:
        file = xbmcvfs.File(path)
        try:
            data = json.loads(file.read())
        finally:
            file.close()
        with open_library() as lib:
            lib.restore_backup(data, ADDON_ID)
    except (OSError, ValueError, OverflowError, sqlite3.Error) as e:
        ok(_(30328) % e)
        return
    _PLAYBACK.clear()
    notify(_(30349))
    xbmc.executebuiltin("Container.Refresh")


def export_library(params):
    folder = setting("library_path")
    if not folder:
        ok(_(30228))
        ADDON.openSettings()
        return
    with open_library() as lib:
        n_movies, n_shows = exporter.export(lib, folder, BASE_URL)
    notify(_(30227) % (n_movies, n_shows, folder), time_ms=8000)
    if yesno(_(30233)):
        xbmc.executebuiltin("UpdateLibrary(video)")


def open_settings(params):
    ADDON.openSettings()


# --- úpravy titulů ---------------------------------------------------------

def repair_title(params):
    key = params["key"]
    add_action(_(30373), "tmdb_repair", key=key)
    add_action(_(30300), "meta_assign", key=key)
    with open_library() as lib:
        meta = lib.get_meta(key)
        videos = lib.videos_for_meta(key)
    for video in videos:
        add_video(video, meta)
    end("videos", cache=False)


def tmdb_repair(params):
    key = params["key"]
    with open_library() as lib:
        meta = lib.get_meta(key)
        videos = lib.videos_for_meta(key)
    if not meta or not videos:
        return
    client = make_tmdb()
    if not client.enabled:
        ok(_(30355))
        ADDON.openSettings()
        return
    raw_title = videos[0]["raw_title"]
    query = keyboard(_(30380) % raw_title, meta["search_title"])
    if not query or not query.strip():
        return
    series = meta["kind"] == "show"
    try:
        candidates = client.search(query.strip(), series)
        if not candidates:
            notify(_(30121))
            return
        labels = ["%s (%s)%s" % (item["title"], item["year"] or "?",
                  " · " + item["orig_title"] if item["orig_title"] and item["orig_title"] != item["title"] else "")
                  for item in candidates]
        choice = select(_(30380) % raw_title, labels)
        if choice < 0:
            return
        info = client.details(candidates[choice]["id"], series)
    except TmdbError as e:
        ok(str(e))
        return
    with open_library() as lib:
        catalog.apply_details(lib, key, info, "tmdb", lock_videos=True)
    notify(_(30320))
    xbmc.executebuiltin("Container.Refresh")


def meta_assign(params):
    key = params["key"]
    with open_library() as lib:
        meta = lib.get_meta(key)
    if not meta:
        return
    want_series = meta["kind"] == "show"
    options = [_(30306), _(30307), _(30308), _(30309)]
    idx = select(_(30300), options)
    if idx < 0:
        return
    try:
        if idx == 0:
            query = keyboard(_(30310), meta["search_title"])
            if not query:
                return
            results = csfd.search(query, log=log)
            if not results:
                notify(_(30121))
                return
            labels = ["%s (%s) – %s" % (r["title"], r["year"] or "?", r["type"]) for r in results]
            pick = select(_(30306), labels)
            if pick < 0:
                return
            info = csfd.details(results[pick]["id"], log=log)
            source = "csfd"
        elif idx == 1:
            text = keyboard(_(30307), meta.get("csfd_url") or "")
            fid = csfd.film_id_from_url(text or "")
            if not fid:
                return
            info = csfd.details(fid, log=log)
            source = "csfd"
        elif idx == 2:
            tmdb = make_tmdb()
            if not tmdb.enabled:
                ok(_(30327))
                return
            query = keyboard(_(30310), meta["search_title"])
            if not query:
                return
            results = tmdb.search(query, want_series)
            if not results:
                notify(_(30121))
                return
            labels = ["%s (%s)%s" % (r["title"], r["year"] or "?",
                                     (" – " + r["orig_title"]) if r["orig_title"] != r["title"] else "")
                      for r in results]
            pick = select(_(30308), labels)
            if pick < 0:
                return
            info = tmdb.details(results[pick]["id"], want_series)
            source = "tmdb"
        else:
            value = number(_(30311), meta.get("rating") or "")
            if value is None:
                return
            info = {"rating": max(0, min(100, value)), "votes": 0}
            source = "manual"
    except csfd.CsfdBlocked:
        ok(_(30216))
        return
    except (csfd.CsfdError, TmdbError) as e:
        ok(_(30328) % e)
        return
    with open_library() as lib:
        if source == "manual":
            lib.update_meta(key, {"rating": info["rating"], "rating_source": "manual",
                                  "status": meta["status"] if meta["status"] == "ok" else "manual"})
        else:
            catalog.apply_details(lib, key, info, source)
    notify(_(30320))
    xbmc.executebuiltin("Container.Refresh")


def meta_refresh(params):
    key = params["key"]
    with open_library() as lib:
        lib.reset_meta(key)
    run_enrich(keys=[key])
    xbmc.executebuiltin("Container.Refresh")


def video_edit(params):
    vid = params["vid"]
    with open_library() as lib:
        v = lib.get_video(vid)
    if not v:
        return
    kind_idx = select(_(30312), [_(30313), _(30314)], preselect=1 if v["kind"] == "episode" else 0)
    if kind_idx < 0:
        return
    title = keyboard(_(30319) if kind_idx == 1 else _(30315), v["title"])
    if not title:
        return
    year = season_ = episode = 0
    if kind_idx == 0:
        year = number(_(30316), v["year"] or "") or 0
        kind = "movie"
    else:
        season_ = number(_(30317), v["season"] or 1) or 1
        episode = number(_(30318), v["episode"] or "") or 0
        kind = "episode"
    with open_library() as lib:
        key = lib.edit_video(vid, kind, title, year, season_, episode)
        meta = lib.get_meta(key)
    if meta and meta["status"] == "new" and setting_bool("auto_meta"):
        run_enrich(keys=[key], quiet=True)
    notify(_(30320))
    xbmc.executebuiltin("Container.Refresh")


def video_hide(params):
    with open_library() as lib:
        lib.set_hidden(params["vid"], params.get("hide", "1") == "1")
    xbmc.executebuiltin("Container.Refresh")


def video_delete(params):
    with open_library() as lib:
        v = lib.get_video(params["vid"])
        if v and yesno(_(30326) % v["raw_title"]):
            lib.delete_video(v["id"])
    xbmc.executebuiltin("Container.Refresh")


def video_info(params):
    with open_library() as lib:
        v = lib.get_video(params["vid"])
        meta = lib.get_meta(v["meta_key"]) if v else None
    if not v:
        return
    lines = ["%s: %s" % (_(30330), v["raw_title"]),
             "ID: %s" % v["id"], provider.video_page_url(v["id"]),
             "%s: %s" % (_(30331), v["lang"] or "?"), "%s: %s" % (_(30332), v["quality"] or "?")]
    if meta:
        lines.append("")
        lines.append("%s: %s (%s)" % (_(30315), _display_title(meta), _display_year(meta) or "?"))
        if meta.get("csfd_url"):
            lines.append("ČSFD: %s" % meta["csfd_url"])
        if meta.get("rating"):
            lines.append("%s: %d %%" % (_(30329), meta["rating"]))
    text_viewer(_(30325), "\n".join(lines))


# --- přehrávání ------------------------------------------------------------

def _pick_stream(streams):
    if len(streams) == 1:
        return streams[0]
    if setting_bool("ask_stream"):
        labels = [" ".join(x for x in (s["lang"], provider.QUALITY_LABEL.get(s["quality"], s["quality"])) if x)
                  + ((" + tit. " + ", ".join(s["subtitles"])) if s["subtitles"] else "")
                  for s in streams]
        idx = select(_(30321), labels)
        return streams[idx] if idx >= 0 else None
    return min(streams, key=_version_score)


def _version_score(video):
    lang = setting_int("pref_lang", 0)
    quality = setting_int("pref_quality", 0)
    pref_lang = LANG_OPTIONS[lang] if 0 <= lang < len(LANG_OPTIONS) else ""
    pref_quality = QUALITY_OPTIONS[quality] if 0 <= quality < len(QUALITY_OPTIONS) else ""
    order = provider.QUALITY_ORDER
    token = video.get("quality", "")
    token = next((key for key, label in provider.QUALITY_LABEL.items() if label == token), token)
    q = order.index(token) if token in order else len(order)
    if pref_quality and q < len(order):
        target = order.index(pref_quality)
        q = q - target if q >= target else len(order) + target - q
    elif pref_quality:
        q = len(order) * 2
    return (bool(pref_lang and video.get("lang") != pref_lang), q)


def _link_cache_get(vid):
    if not provider.LINK_TTL or setting_bool("ask_stream"):
        return None
    with open_library() as lib:
        raw = lib.get_kv("link:" + vid)
    try:
        data = json.loads(raw) if raw else None
    except ValueError:
        return None
    if data and time.time() - data.get("ts", 0) < provider.LINK_TTL:
        return data
    return None


def _link_cache_put(vid, final, subtitles, fallback_height):
    if not provider.LINK_TTL:
        return
    with open_library() as lib:
        lib.set_kv("link:" + vid, json.dumps({"url": final, "subtitles": subtitles,
                                                              "fallback_height": fallback_height, "ts": int(time.time())}))


def play(params):
    vid = params["vid"]
    cached = _link_cache_get(vid)
    if cached:
        log("play %s: adresa z paměti" % vid)
        _resolved(vid, cached["url"], cached.get("subtitles") or {}, cached.get("fallback_height"))
        return
    client = make_client()
    try:
        streams, message = client.get_streams(vid)
        if not streams:
            raise provider.ProviderError(message or _(30322))
        if message:
            notify(message)
        stream = _pick_stream(streams)
        if stream is None:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        final = client.resolve(stream["url"])
    except provider.ProviderError as e:
        log_error("play %s: %s" % (vid, e))
        notify(_(30323) % e, time_ms=8000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    subtitles = stream.get("subtitles") or {}
    fallback_height = getattr(client, "fallback_height", None)
    _link_cache_put(vid, final, subtitles, fallback_height)
    _resolved(vid, final, subtitles, fallback_height)


def _resolved(vid, final, subtitles, fallback_height=None):
    if fallback_height:
        notify(_(30344) % fallback_height)
    li = xbmcgui.ListItem(path=final + "|User-Agent=" + urllib.parse.quote(provider.USER_AGENT))
    if final.split("?")[0].lower().endswith(".mp4"):
        li.setMimeType("video/mp4")
        li.setContentLookup(False)
    if setting_bool("subtitles") and subtitles:
        li.setSubtitles(list(subtitles.values()))
    # služba na pozadí podle toho zapisuje, kde se ve videu skončilo
    xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, vid)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


ROUTES = {
    "root": root, "movies_menu": movies_menu, "movies": movies, "movie_genres": movie_genres,
    "movie_decades": movie_decades, "movie_countries": movie_countries,
    "movie_ratings": movie_ratings, "versions": versions, "shows_menu": shows_menu, "shows": shows,
    "show": show, "season": season, "recent": recent, "all_videos": all_videos, "unmatched": unmatched, "hidden": hidden,
    "search_menu": search_menu, "search": search, "search_delete": search_delete,
    "provider_search": provider_search, "provider_save": provider_save,
    "tmdb_catalog": tmdb_catalog, "tmdb_categories": tmdb_categories,
    "tmdb_filters": tmdb_filters, "tmdb_titles": tmdb_titles, "tmdb_title": tmdb_title,
    "my_videos_menu": my_videos_menu, "tmdb_search": tmdb_search,
    "tmdb_movie_versions": tmdb_movie_versions,
    "watchlist": watchlist, "watchlist_change": watchlist_change,
    "repair_title": repair_title, "tmdb_repair": tmdb_repair, "season_status": season_status,
    "backup_catalog": backup_catalog, "restore_catalog": restore_catalog,
    "collections": collections, "collection": collection, "collection_new": collection_new,
    "collection_rename": collection_rename, "collection_delete": collection_delete,
    "collection_add": collection_add, "collection_remove": collection_remove,
    "tools": tools, "sync": sync, "enrich": enrich, "refresh_all": refresh_all,
    "add_link": add_link, "import_file": import_file, "account_status": account_status,
    "stats": stats, "clear_library": clear_library, "export_library": export_library,
    "settings": open_settings, "meta_assign": meta_assign, "meta_refresh": meta_refresh,
    "video_edit": video_edit, "video_hide": video_hide, "video_delete": video_delete,
    "video_info": video_info, "play": play, "in_progress": in_progress, "played": played,
    "history_remove": history_remove, "history_clear": history_clear, "diagnostics": diagnostics,
}


def run(argv=None):
    global BASE_URL, HANDLE
    argv = argv or sys.argv
    BASE_URL = argv[0]
    HANDLE = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith("?") else (argv[2] if len(argv) > 2 else "")
    params = dict(urllib.parse.parse_qsl(query))
    action = params.get("action", "root")
    log("route %s %s" % (action, dict((k, v) for k, v in params.items() if k != "action")))
    handler = ROUTES.get(action)
    if handler is None:
        log_error("neznámá akce %s" % action)
        return
    handler(params)
